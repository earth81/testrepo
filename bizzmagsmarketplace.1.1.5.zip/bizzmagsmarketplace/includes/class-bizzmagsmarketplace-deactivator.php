<?php
/**
 * @package    BizzmagsMarketplace
 * @author     Claudiu Maftei <admin@bizzmags.ro>
 */
namespace BizzmagsMarketplace;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 

class BizzmagsMarketplace_Deactivator {

	public function deactivate() {

	}

}
